package com.altapay.backend.model;

import lombok.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Builder
public class Inventory 
{
	private Product product;
	private int inventory;
}
