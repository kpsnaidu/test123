package com.altapay.backend.model;

import lombok.*;

import java.util.List;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Builder(toBuilder = true)
public class ShopOrder 
{
	String id;
	String paymentId;
	List<OrderLine> orderLines;
}
