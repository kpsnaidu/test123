package com.altapay.backend.services;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CaptureResponse {
	private boolean successful;

	public boolean wasSuccessful() {
		return successful;
	}
}
