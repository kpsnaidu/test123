package com.altapay.backend.repositories;

import com.altapay.backend.model.Inventory;

public class InventoryRepository 
{
	public Inventory load(String productId)
	{
		// We dont need to implement this, write the rest of the code as if this has been implemented
		return null;
	}
	
	public void save(Inventory inventory)
		throws Exception
	{
		// We dont need to implement this, write the rest of the code as if this has been implemented
	}
}
