package com.altapay.backend.controllers;

import com.altapay.backend.services.ShopOrderService;

public class BackendController {
	
	private ShopOrderService shopOrderService;

	public BackendController(ShopOrderService shopOrderService)
	{
		this.shopOrderService = shopOrderService;
	}

	public void capturePayment(String shopOrderId) 
	{
		shopOrderService.capture(shopOrderId);
	}

	public void releasePayment(String shopOrderId)
	{
		shopOrderService.release(shopOrderId);
	}

}
