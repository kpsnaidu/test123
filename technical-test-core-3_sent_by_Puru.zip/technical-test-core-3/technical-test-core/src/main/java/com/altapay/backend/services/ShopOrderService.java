package com.altapay.backend.services;

import com.altapay.backend.exceptions.MerchantApiServiceException;
import com.altapay.backend.model.OrderLine;
import com.altapay.backend.model.ShopOrder;
import com.altapay.backend.repositories.ShopOrderRepository;

import java.util.List;
import java.util.stream.Collectors;

public class ShopOrderService {

    private ShopOrderRepository shopOrderRepository;
    private InventoryService inventoryService;
    private MerchantApiService merchantApiService;

    public ShopOrderService(ShopOrderRepository shopOrderRepository, InventoryService inventoryService,
                            MerchantApiService merchantApiService)
    {
        this.shopOrderRepository = shopOrderRepository;
        this.inventoryService = inventoryService;
        this.merchantApiService = merchantApiService;
    }
    public void capture(String shopOrderId)
    {
        ShopOrder order = shopOrderRepository.loadShopOrder(shopOrderId);

        // TODO: use the InventoryService to check inventory before capturing
        List<OrderLine> inventoryAvailableOrderLines = order.getOrderLines().stream().filter(so ->
                inventoryService.checkInventory(so.getProduct(), so.getQuantity())).collect(Collectors.toList());

        ShopOrder shopOrderToBeFulfilled = order.toBuilder().orderLines(inventoryAvailableOrderLines).build();
        boolean paymentSuccessful;
        // TODO: Use the MerchantApiService to capture the payment.
        try {
            CaptureResponse captureResponse = merchantApiService.capturePayment(shopOrderToBeFulfilled);
            paymentSuccessful = captureResponse.wasSuccessful();
        } catch (MerchantApiServiceException e) {
            System.out.println("payment capture error for shop order id::"+shopOrderId + ":: exception::"+e.getMessage());
            paymentSuccessful = false;
        }
        // TODO: use the InventoryService to take from inventory after capturing

        if(paymentSuccessful){
            inventoryAvailableOrderLines.forEach(so -> inventoryService.takeFromInventory(so.getProduct(), so.getQuantity()));
            // TODO: Save the model after capturing
            shopOrderRepository.saveShopOrder(shopOrderToBeFulfilled);
        } else {
            System.out.println("Unable to capture the shop order for id::"+ shopOrderId + "::due to payment unsuccessful");
        }

    }


    // Release is a synonym for canceling a payment
    public void release(String shopOrderId) {

        ShopOrder order = shopOrderRepository.loadShopOrder(shopOrderId); // TODO: load the shop order

        boolean isPaymentReleased;
        // TODO: Use the MerchantApiService to release the payment.
        try {
            ReleaseResponse releaseResponse = merchantApiService.releasePayment(order);
            isPaymentReleased = releaseResponse.wasSuccessful();
        } catch (MerchantApiServiceException e) {
            System.out.println("payment release error for shop order id::"+shopOrderId + ":: exception::"+e.getMessage());
            isPaymentReleased = false;
        }

        if (isPaymentReleased){
            // TODO: Save the model after releasing
            shopOrderRepository.saveShopOrder(order);
        } else {
            System.out.printf("unable to release the payment for shop oder id ::"+shopOrderId);
        }

    }
}
