package com.altapay.backend.model;

import lombok.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@Builder(toBuilder = true)
public class OrderLine {
	private Product product;
	private int quantity;
}
