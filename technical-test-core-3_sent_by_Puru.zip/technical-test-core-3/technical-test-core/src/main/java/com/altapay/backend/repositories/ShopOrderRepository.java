package com.altapay.backend.repositories;


import java.util.ArrayList;
import java.util.List;

import com.altapay.backend.model.IModelFactory;
import com.altapay.backend.model.OrderLine;
import com.altapay.backend.model.Product;
import com.altapay.backend.model.ShopOrder;

public class ShopOrderRepository {
	
	private IModelFactory modelFactory;

	public ShopOrderRepository(IModelFactory modelFactory)
	{
		this.modelFactory = modelFactory;
	}
	
	public ShopOrder loadShopOrder(String shopOrderId)
	{
		ShopOrder order = modelFactory.getShopOrder();

		List<OrderLine> orderLines = new ArrayList<OrderLine>();
		orderLines.add(getOrderLine("1","Keyboard",1));

		return order.toBuilder().id(shopOrderId).orderLines(orderLines).build();

	}
	
	private OrderLine getOrderLine(String productId, String name, int quantity) 
	{
		OrderLine orderLine = modelFactory.getOrderLine();
		Product product = modelFactory.getProduct();
		Product updatedProduct = product.toBuilder().id(productId).name(name).build();

		OrderLine updatedOrderLine = orderLine.toBuilder().product(updatedProduct).quantity(quantity).build();

		return updatedOrderLine;
	}

	public void saveShopOrder(ShopOrder shopOrder)
	{
		System.out.println("Hurray, you saved the shopOrder: "+shopOrder);
	}

}
