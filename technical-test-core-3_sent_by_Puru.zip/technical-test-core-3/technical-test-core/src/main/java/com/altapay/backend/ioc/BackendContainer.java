package com.altapay.backend.ioc;

import com.altapay.backend.controllers.BackendController;
import com.altapay.backend.model.IModelFactory;
import com.altapay.backend.model.Inventory;
import com.altapay.backend.model.OrderLine;
import com.altapay.backend.model.Product;
import com.altapay.backend.model.ShopOrder;
import com.altapay.backend.repositories.InventoryRepository;
import com.altapay.backend.repositories.ShopOrderRepository;
import com.altapay.backend.services.InventoryService;
import com.altapay.backend.services.MerchantApiService;
import com.altapay.backend.services.ShopOrderService;

public class BackendContainer implements IModelFactory {

	private static ShopOrderRepository shopOrderRepository;

	public BackendController getBackendController() 
	{
		ShopOrderService shopOrderService = new ShopOrderService(getShopOrderRepository(), new InventoryService(new InventoryRepository()), new MerchantApiService(null, null));
		return new BackendController(shopOrderService);
	}

	// TODO: should be a singleton
	public ShopOrderRepository getShopOrderRepository() 
	{
		if(shopOrderRepository == null){
			shopOrderRepository = new ShopOrderRepository(this);
		}
		return shopOrderRepository;
	}
	
	@Override
	public ShopOrder getShopOrder() 
	{
		// TODO: initialize a new ShopOrder with it's dependencies
		return new ShopOrder();
	}

	@Override
	public Inventory getInventory() 
	{
		// TODO: initialize a new Inventory with it's dependencies
		return new Inventory();
	}

	@Override
	public OrderLine getOrderLine() 
	{
		// TODO: initialize a new OrderLine with it's dependencies
		return new OrderLine();
	}

	@Override
	public Product getProduct() 
	{
		// TODO: initialize a new Product with it's dependencies
		return new Product();
	}

}
