package com.altapay.backend.exceptions;

public class MerchantApiServiceException extends Exception {

}
