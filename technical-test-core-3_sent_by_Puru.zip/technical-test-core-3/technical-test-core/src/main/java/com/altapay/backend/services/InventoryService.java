package com.altapay.backend.services;

import com.altapay.backend.model.Inventory;
import com.altapay.backend.model.Product;
import com.altapay.backend.repositories.InventoryRepository;

public class InventoryService 
{
	private InventoryRepository repository;

	public InventoryService(InventoryRepository repository)
	{
		this.repository = repository;
	}
	
	public boolean checkInventory(Product product, int quantity)
	{
		// TODO: implement check inventory, as you see fit
		Inventory inventory = repository.load(product.getId());

		if(inventory.getInventory() >= quantity)
			return true;

		return false;
	}
	
	public boolean takeFromInventory(Product product, int quantity)
	{
		// TODO: implement take from inventory, as you see fit
		Inventory inventory = repository.load(product.getId());
		int currentQuantity = inventory.getInventory();

		int futureQuantity = currentQuantity - quantity;
		Inventory futureInventory = Inventory.builder().product(inventory.getProduct()).inventory(futureQuantity).build();
		try {
			repository.save(futureInventory);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}
