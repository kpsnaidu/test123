package com.altapay.backend.services;


import com.altapay.backend.exceptions.MerchantApiServiceException;
import com.altapay.backend.ioc.BackendContainer;
import com.altapay.backend.model.Inventory;
import com.altapay.backend.model.OrderLine;
import com.altapay.backend.model.Product;
import com.altapay.backend.model.ShopOrder;
import com.altapay.backend.repositories.InventoryRepository;
import com.altapay.backend.repositories.ShopOrderRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import static org.mockito.Mockito.*;

public class ShopOrderServiceTest {

    public static final String PRODUCT_ID = "1234";
    public static final String SHOP_ORDER_ID = "10";
    @Mock
    private ShopOrderRepository shopOrderRepository;
    @Mock
    private InventoryService inventoryService;
    @Mock
    private MerchantApiService merchantApiService;

    private Product aProduct;
    private Inventory anInventory;
    private ShopOrderService shopOrderService;
    private ShopOrder shopOrder;

    @Before
    public void setup()
    {
        MockitoAnnotations.initMocks(this);
        aProduct = Product.builder().id(PRODUCT_ID).name("product1234").build();
        OrderLine orderLine = OrderLine.builder().quantity(2).product(aProduct).build();

        anInventory = Inventory.builder().product(aProduct).inventory(5).build();
        shopOrder = ShopOrder.builder().id(SHOP_ORDER_ID)
                .paymentId("p123").orderLines(Collections.singletonList(orderLine)).build();
        when(shopOrderRepository.loadShopOrder(SHOP_ORDER_ID)).thenReturn(shopOrder);
        shopOrderService = new ShopOrderService(shopOrderRepository, inventoryService, merchantApiService);
    }

    @Test
    public void Test_WhenCaptureTheShopOrderAndPaymentSuccessful_ThenShouldTakeFromInventoryAndSaveShopOrder() throws MerchantApiServiceException{
        when(inventoryService.checkInventory(aProduct, 2)).thenReturn(true);
        when(merchantApiService.capturePayment(shopOrder)).thenReturn(new CaptureResponse(true));

        shopOrderService.capture(SHOP_ORDER_ID);
        verify(inventoryService).takeFromInventory(aProduct,2);
        verify(shopOrderRepository).saveShopOrder(shopOrder);
    }

    @Test
    public void Test_WhenCaptureTheShopOrderAndPaymentUnSuccessful_ThenShouldNotTakeFromInventoryAndNotToSaveShopOrder() throws MerchantApiServiceException{
        when(inventoryService.checkInventory(aProduct, 2)).thenReturn(true);
        when(merchantApiService.capturePayment(shopOrder)).thenReturn(new CaptureResponse(false));

        shopOrderService.capture(SHOP_ORDER_ID);
        verify(inventoryService, times(0)).takeFromInventory(aProduct,2);
        verify(shopOrderRepository, times(0)).saveShopOrder(shopOrder);
    }

    @Test
    public void Test_WhenCaptureTheShopOrderAndPaymentThrowedException_ThenShouldNotTakeFromInventoryAndNotToSaveShopOrder() throws MerchantApiServiceException{
        when(inventoryService.checkInventory(aProduct, 2)).thenReturn(true);
        doThrow(new MerchantApiServiceException()).when(merchantApiService).capturePayment(shopOrder);

        shopOrderService.capture(SHOP_ORDER_ID);
        verify(inventoryService, times(0)).takeFromInventory(aProduct,2);
        verify(shopOrderRepository, times(0)).saveShopOrder(shopOrder);
    }

    @Test
    public void Test_WhenReleaseTheShopOrderPaymentSuccessful_ThenShouldSaveShopOrder() throws MerchantApiServiceException{

        when(merchantApiService.releasePayment(shopOrder)).thenReturn(new ReleaseResponse(true));

        shopOrderService.release(SHOP_ORDER_ID);

        verify(shopOrderRepository).saveShopOrder(shopOrder);
    }

    @Test
    public void Test_WhenReleaseTheShopOrderPaymentUnSuccessful_ThenShouldNotSaveShopOrder() throws MerchantApiServiceException{

        when(merchantApiService.releasePayment(shopOrder)).thenReturn(new ReleaseResponse(false));

        shopOrderService.release(SHOP_ORDER_ID);

        verify(shopOrderRepository, times(0)).saveShopOrder(shopOrder);
    }

    @Test
    public void Test_WhenReleaseTheShopOrderPaymentThrowsTheException_ThenShouldNotSaveShopOrder() throws MerchantApiServiceException{

        doThrow(new MerchantApiServiceException()).when(merchantApiService).releasePayment(shopOrder);

        shopOrderService.release(SHOP_ORDER_ID);

        verify(shopOrderRepository, times(0)).saveShopOrder(shopOrder);
    }
}