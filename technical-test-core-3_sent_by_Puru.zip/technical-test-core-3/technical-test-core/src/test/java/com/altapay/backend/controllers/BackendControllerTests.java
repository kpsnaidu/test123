package com.altapay.backend.controllers;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.altapay.backend.services.ShopOrderService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.altapay.backend.model.ShopOrder;
import com.altapay.backend.repositories.ShopOrderRepository;

public class BackendControllerTests {

	private static final String ORDER_ID = "Some order id";

	@Mock
	private ShopOrderService shopOrderService;

	// The object to be tested
	private BackendController controller;

	@Before
	public void setup() 
	{
		MockitoAnnotations.initMocks(this);
		
		controller = new BackendController(shopOrderService);
	}
	
	@Test
	public void captureReservationGetsTheOrderFromTheRepository()
	{
		controller.capturePayment(ORDER_ID);
		
		verify(shopOrderService).capture(ORDER_ID);
	}

	@Test
	public void captureReservationMustInvokeCaptureOnTheOrder()
	{
		controller.capturePayment(ORDER_ID);
		
		verify(shopOrderService).capture(ORDER_ID);
	}

	@Test
	public void releaseShopOrderPaymentMustInvokeReleasePayment()
	{
		controller.releasePayment(ORDER_ID);

		verify(shopOrderService).release(ORDER_ID);
	}
}
