package com.altapay.backend.model;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

@Ignore(value = "need to rewrite as the behaviour of ShopOrder refactored and moved to ShopOrderService")
public class ShopOrderTest {

	private static final String ID = "orderid";
	private static final String PAYMENT_ID = "paymentid";
	private ShopOrder order;

	@Before
	public void setUp() throws Exception 
	{
		order = ShopOrder.builder().id(ID).paymentId(PAYMENT_ID).build();
	}

	@Test
	public void executeCapture_inventoryIsChecked() 
	{
		// TODO: Implement test
		fail("Not yet implemented");
	}

	@Test
	public void executeCapture_paymentIsCapturedThroughApiService() 
	{
		// TODO: Implement test
		fail("Not yet implemented");
	}
		
	@Test
	public void executeRelease_paymentIsReleasedThroughApiService() 
	{
		// TODO: Implement test
		fail("Not yet implemented");
	}
	
	// TODO: Add more tests you think is relevant
}
