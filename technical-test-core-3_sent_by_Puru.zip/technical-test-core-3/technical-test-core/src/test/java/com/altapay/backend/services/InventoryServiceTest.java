package com.altapay.backend.services;


import com.altapay.backend.model.Inventory;
import com.altapay.backend.model.Product;
import com.altapay.backend.repositories.InventoryRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class InventoryServiceTest {

    public static final String PRODUCT_ID = "1234";
    @Mock
    private InventoryRepository inventoryRepository;

    private InventoryService inventoryService;
    private Product aProduct;
    private Inventory anInventory;

    @Before
    public void setup()
    {
        MockitoAnnotations.initMocks(this);
        aProduct = Product.builder().id(PRODUCT_ID).name("product1234").build();

        anInventory = Inventory.builder().product(aProduct).inventory(5).build();
        when(inventoryRepository.load(PRODUCT_ID)).thenReturn(anInventory);
        inventoryService = new InventoryService(inventoryRepository);
    }

    @Test
    public void shouldReturnTrueIfProductQuantityAvailableOnCheckInventory()
    {
        Assert.assertTrue(inventoryService.checkInventory(aProduct, 3));
        Assert.assertTrue(inventoryService.checkInventory(aProduct, 5));

    }

    @Test
    public void shouldReturnFalseIfProductQuantityNotAvailableOnCheckInventory()
    {
        Assert.assertFalse(inventoryService.checkInventory(aProduct, 6));
        Assert.assertFalse(inventoryService.checkInventory(aProduct, 10));
    }

    @Test
    public void shouldReturnTrueIfTakeOutFromInventorySuccessful() {

       Assert.assertTrue(inventoryService.takeFromInventory(aProduct, 2));

    }

    @Test
    public void shouldReturnFalseIfTakeOutFromInventoryUnSuccessful() throws Exception {

        doThrow(new Exception()).when(inventoryRepository).save(anyObject());
        Assert.assertFalse(inventoryService.takeFromInventory(aProduct, 2));

    }
}